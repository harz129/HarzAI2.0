import os
import requests
import io
import time
import sys
from pathlib import Path
from PIL import Image
from dotenv import load_dotenv

load_dotenv()

# Ensure the console can handle emojis
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass


# --- Configuration & Pathing ---
# Grab your token from https://huggingface.co/settings/tokens
HF_TOKEN = os.getenv("HF_TOKEN") or "your_hugging_face_token_here"
MODEL_ID = "black-forest-labs/FLUX.1-schnell"
API_URL = f"https://router.huggingface.co/hf-inference/models/{MODEL_ID}"
HEADERS = {"Authorization": f"Bearer {HF_TOKEN}"}

# Directories based on your setup
PROMPT_FILE = Path("Backend/Files/ImageGeneration.Data")
SAVE_DIR = Path("Data")

def gemini(prompt_input: str):
    """
    Main function that mirrors your original logic: 
    Cleans the prompt, saves it to the file, then triggers the generation.
    """
    # 1. Clean the input
    clean_prompt = prompt_input.lower().replace("generate image", "").strip()
    
    if not clean_prompt:
        return

    # 2. Sync with your data file
    PROMPT_FILE.parent.mkdir(parents=True, exist_ok=True)
    PROMPT_FILE.write_text(clean_prompt, encoding="utf-8")

    # 3. Pull the prompt BACK from the file (as requested)
    prompt_from_file = PROMPT_FILE.read_text(encoding="utf-8").strip()

    # 4. Generate & Save
    generate_and_save(prompt_from_file)

def generate_and_save(prompt: str):
    """Hits the HF API and saves the result in /Images."""
    SAVE_DIR.mkdir(parents=True, exist_ok=True)
    
    print(f"🎨 Processing prompt from file: '{prompt}'...")

    try:
        response = requests.post(API_URL, headers=HEADERS, json={"inputs": prompt}, timeout=30)
        
        if response.status_code == 200:
            image = Image.open(io.BytesIO(response.content))
            
            # Timestamped filename so you don't overwrite your own heat
            timestamp = int(time.time())
            file_path = SAVE_DIR / f"img_{timestamp}.png"
            
            image.save(file_path)
            print(f"✨ Major W! Image saved to: {file_path}")
            os.startfile(file_path)
        else:
            print(f"💀 API Error {response.status_code}: {response.text}")
            
    except Exception as e:
        print(f"🚫 Something went sideways: {e}")

